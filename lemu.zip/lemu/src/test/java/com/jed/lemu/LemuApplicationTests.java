package com.jed.lemu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LemuApplicationTests {

	@Test
	void contextLoads() {
	}

}
