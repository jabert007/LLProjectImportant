package com.jed.lemu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LemuApplication {

	public static void main(String[] args) {
		SpringApplication.run(LemuApplication.class, args);
	}

}
